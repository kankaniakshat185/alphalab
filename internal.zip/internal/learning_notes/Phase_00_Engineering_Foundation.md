# Phase 00 — Engineering Foundation
## Learning Notes

> **Phase:** 0 — Engineering Foundation
> **Date:** 2026-07-05

---

## Concept 1 — The `src/` Layout

### Definition

The `src/` layout is a Python project structure where the installable package
is placed inside a `src/` directory, rather than directly in the project root.

```
# src/ layout (what AlphaLab uses)
my-project/
  src/
    mypackage/
      __init__.py
  tests/
  pyproject.toml

# flat layout (common but has failure modes)
my-project/
  mypackage/
    __init__.py
  tests/
  pyproject.toml
```

### History

Before `pip` became the standard Python package manager, most projects used
a flat layout with `setup.py` directly in the root. This worked when package
installation was simple. As packaging became more sophisticated, a subtle bug
emerged: with the flat layout, `import mypackage` resolves to the local
directory even without installation — which means tests pass locally
but may fail in CI where the package isn't installed correctly.

The `src/` layout was proposed as a solution by Hynek Schlawack in 2019 and
has since been adopted as the recommended approach by the Python Packaging
Authority (PyPA).

### The Problem the `src/` Layout Solves

With a flat layout:
```
my-project/
  mypackage/      ← this directory is on sys.path
  tests/
  pyproject.toml
```

Running `python -c "import mypackage"` from the project root works even without
`pip install`. This means:
- A developer who forgets `pip install -e .` still gets imports working locally
- Their tests pass
- CI fails because the install step actually doesn't work correctly
- The failure is discovered late, in CI, not immediately

With the `src/` layout:
```
my-project/
  src/
    mypackage/    ← NOT on sys.path by default
  tests/
  pyproject.toml
```

Running `python -c "import mypackage"` fails unless you've installed with
`pip install -e .`. This makes installation failures visible immediately,
at the developer's machine, not in CI.

### How AlphaLab Uses It

AlphaLab places the package at `src/alphalab/`. All imports must go through
`pip install -e ".[dev]"`. The `install.yml` CI workflow verifies this on
every push.

The `pyproject.toml` build configuration:
```toml
[tool.hatch.build.targets.wheel]
packages = ["src/alphalab"]
```

### Interview Questions

**Q: Why use `src/` layout instead of the flat layout?**
A: The `src/` layout prevents a subtle failure mode: in a flat layout, Python
resolves `import mypackage` to the project root even without installation,
which means you can't detect broken installations locally. With `src/`, the
package is only importable after `pip install -e .`, making the test
environment identical to the deployment environment.

**Q: What is `pip install -e .` and why use it?**
A: The `-e` (editable) flag installs the package in a way that changes to
the source files are reflected immediately without reinstalling. This is
the correct development mode for any project using the `src/` layout.

---

## Concept 2 — `pyproject.toml` and the Python Packaging Ecosystem

### Definition

`pyproject.toml` is the modern, PEP-standardised configuration file for Python
packages. It replaces the older `setup.py` (imperative Python) and `setup.cfg`
(declarative INI) formats.

### History

| Era | Format | Problem |
|---|---|---|
| Pre-2012 | `setup.py` | Imperative; ran arbitrary Python during install |
| 2012–2016 | `setup.cfg` | Declarative but `setuptools`-specific |
| 2016–2021 | Both | Transition period; both needed simultaneously |
| 2021+ | `pyproject.toml` | PEP 517/518/621; build-system agnostic |

**PEP 517 (2017):** Defined a standard interface between build tools and
installers. Before PEP 517, `pip` directly executed `setup.py` — which meant
every project had to use `setuptools`. PEP 517 allows any build backend.

**PEP 518 (2017):** Required projects to declare their build dependencies in
`pyproject.toml` under `[build-system]`. This is why `pyproject.toml` exists.

**PEP 621 (2020):** Standardised the `[project]` metadata section so all build
backends can read the same fields.

### Structure of AlphaLab's `pyproject.toml`

```toml
[build-system]          # PEP 518: which build backend to use
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]               # PEP 621: package metadata
name = "alphalab"
version = "0.1.0"
requires-python = ">=3.12"
dependencies = []       # runtime deps — empty in Phase 0

[project.optional-dependencies]
dev = [...]             # dev deps: pytest, ruff, mypy

[tool.ruff]             # tool-specific config (not standardised)
[tool.mypy]
[tool.pytest.ini_options]
[tool.coverage.run]
```

### Why Hatchling?

Hatchling is a modern, lightweight build backend that:
- Handles the `src/` layout cleanly with minimal configuration
- Is actively maintained by the PyPA
- Produces clear error messages

Alternatives: `setuptools` (traditional, more complex for `src/` layout),
`flit` (simpler but less flexible), `poetry` (opinionated, uses its own
lock file format which conflicts with `pyproject.toml` standards).

### Interview Questions

**Q: What is the difference between `dependencies` and `optional-dependencies`?**
A: `dependencies` are installed in all environments. `optional-dependencies`
are grouped under a name (e.g., `dev`) and installed only when requested
with `pip install -e ".[dev]"`. This separation keeps production installs lean.

---

## Concept 3 — Pre-commit Hooks

### Definition

Pre-commit is a framework for managing Git hooks. A Git hook is a script that
runs automatically at specific points in the Git workflow. The most common
hook is the pre-commit hook, which runs before a commit is created.

### Why Pre-commit?

Without pre-commit:
1. Developer writes code
2. Developer commits
3. CI runs lint → finds errors
4. Developer fixes errors
5. Developer commits again
6. CI runs lint again

With pre-commit:
1. Developer writes code
2. Developer commits → pre-commit runs lint automatically
3. If lint fails, commit is rejected with the error
4. Developer fixes errors
5. Developer commits → lint passes → commit succeeds
6. CI runs lint → passes (because pre-commit already caught all errors)

The shift is: catch errors at the developer's machine in milliseconds,
rather than in CI in minutes.

### AlphaLab's Hooks

```yaml
- end-of-file-fixer      # every file ends with exactly one newline
- trailing-whitespace    # no trailing spaces
- check-yaml             # all .yml/.yaml files are valid YAML
- check-toml             # pyproject.toml is valid TOML
- check-added-large-files # no files over 500KB
- check-merge-conflict   # no leftover <<<<<<< markers
- no-commit-to-branch    # can't commit directly to main or dev
- ruff                   # linting with auto-fix
- ruff-format            # code formatting
```

The `no-commit-to-branch` hook is particularly valuable: it prevents accidental
direct commits to `main` or `dev`, enforcing the branch protection policy
even before GitHub's server-side rules apply.

### Interview Questions

**Q: Why use pre-commit if CI already runs the same checks?**
A: Pre-commit catches issues at the developer's machine in < 1 second.
CI runs the same checks in 2–3 minutes in a remote environment. Pre-commit
doesn't replace CI — it makes CI a last-resort check rather than the primary
feedback mechanism. Faster feedback loops mean more productive development.

---

## Concept 4 — GitHub Actions

### Definition

GitHub Actions is a CI/CD platform built into GitHub. It runs automated
workflows triggered by events in a repository (pushes, pull requests, etc.).

### Architecture

```
Event (push to dev)
    ↓
Workflow file (.github/workflows/lint.yml)
    ↓
Job (lint)
    ↓
Steps:
    checkout → setup-python → pip install → ruff → mypy
```

**Event:** What triggers the workflow (push, pull_request, schedule, etc.)
**Workflow:** A YAML file defining what to run
**Job:** A set of steps that run in sequence on the same runner
**Step:** A single action (checkout code, run a command, etc.)
**Runner:** The virtual machine that executes the job (ubuntu-latest = Ubuntu 22.04)

### AlphaLab's Three Workflows

**`lint.yml`** — catches code quality issues:
```yaml
on: [push, pull_request]  # runs on every push and PR
jobs:
  lint:
    steps:
      - ruff check .        # linting
      - mypy src/           # type checking
```

**`test.yml`** — catches regressions:
```yaml
jobs:
  test:
    steps:
      - pytest tests/       # full test suite
```

**`install.yml`** — catches packaging errors:
```yaml
jobs:
  install:
    # No pip cache — must be genuinely clean
    steps:
      - pip install -e ".[dev]"    # full install
      - python -c "import alphalab" # verify it works
```

The `install.yml` workflow uses no pip cache. This is intentional: caching
the pip state would hide errors in `pyproject.toml`. A clean install from
scratch is required to catch packaging problems.

### Interview Questions

**Q: Why three separate workflow files instead of one combined workflow?**
A: Separate workflows fail independently. If linting fails, you still see
test results. If tests fail, you still see install results. With a single
workflow, the first failing step stops all subsequent steps, reducing visibility.
Separate workflows also allow different trigger conditions in the future
(e.g., install only on pushes to main, not every PR).

---

## Concept 5 — Docker Compose

### Definition

Docker Compose is a tool for defining and running multi-container Docker
applications. A single YAML file describes all services, their configuration,
networks, and volumes.

### Why Docker Compose for Development?

Without Docker Compose, every developer must manually install, configure,
and start PostgreSQL and Redis on their local machine. These services
must match the production versions exactly. This is error-prone and
creates "works on my machine" problems.

With Docker Compose:
```bash
docker compose up -d    # starts PostgreSQL and Redis in Docker containers
docker compose down     # stops them
docker compose down -v  # stops them and deletes all data
```

Every developer gets an identical, isolated set of services.

### AlphaLab's Services

```yaml
postgres:
  image: postgres:16-alpine   # pinned version — never use :latest
  ports: ["5432:5432"]
  volumes: [postgres_data:/var/lib/postgresql/data]  # data persists
  healthcheck: pg_isready     # other services wait until postgres is ready

redis:
  image: redis:7-alpine
  command: redis-server --appendonly yes --requirepass ${REDIS_PASSWORD}
  ports: ["6379:6379"]

pgadmin:
  profiles: [tools]           # only starts with --profile tools
  depends_on:
    postgres:
      condition: service_healthy  # waits for postgres health check
```

### The Profile Pattern

Docker Compose profiles allow services to be grouped and started selectively.
AlphaLab uses `profiles: [tools]` for pgAdmin — a developer convenience
tool that doesn't need to run during testing.

```bash
# Start only core services
docker compose up -d

# Start everything including GUI
docker compose --profile tools up -d
```

### Named Volumes vs Bind Mounts

```yaml
volumes:
  postgres_data:/var/lib/postgresql/data  # named volume
  ./local-dir:/container-dir              # bind mount
```

Named volumes are managed by Docker. Their data persists across container
restarts and recreations. Bind mounts expose a local directory directly
inside the container — good for development (code changes are immediate)
but not for database data (database file formats are Docker-internal).

### Interview Questions

**Q: Why pin PostgreSQL to version 16 instead of using `:latest`?**
A: `:latest` changes without warning. A new PostgreSQL major version (17, 18)
introduces schema or protocol changes that can break the application.
Pinning to `16-alpine` means "use any patch release of PostgreSQL 16,
but never automatically upgrade to 17." Explicit versioning is a reliability
and reproducibility requirement.

---

## Concept 6 — The Four-File Documentation System

### The Problem It Solves

Software projects accumulate context over time: why was this decision made?
What was tried and rejected? What is the next step? Without a system for
capturing this context, a new engineer (or a returning one after a break,
or an AI agent) must reconstruct it from code, commit history, and memory.

The four-file system provides four documents with four distinct purposes
and four distinct update cadences:

| Document | Purpose | Changes when |
|---|---|---|
| `00_MASTER_PLAN.md` | Project constitution | Rarely — major pivots only |
| `01_ARCHITECTURE.md` | System description | After every phase |
| `02_CURRENT_STATE.md` | Continuous changelog | After every task |
| `03_NEXT_STAGE.md` | Next milestone only | When current milestone completes |

### Why Four Documents, Not One?

A single document that serves all four purposes becomes either too long
(overwhelming) or too short (superficial). Separating by update cadence
means:
- The constitution is stable and authoritative
- The architecture reflects the current system accurately
- The current state is always up to date
- The next stage is concrete and actionable

### The `03_NEXT_STAGE.md` Discipline

`03_NEXT_STAGE.md` contains exactly one upcoming milestone. When that
milestone is complete, its content is archived into `02_CURRENT_STATE.md`
and `03_NEXT_STAGE.md` is rewritten for the next milestone.

This prevents two failure modes:
1. Documenting future phases in too much detail (wasted effort if plans change)
2. Not documenting the next step at all (context loss)

---

## Concept 7 — Architectural Decision Records (ADRs)

### Definition

An Architectural Decision Record (ADR) is a document that captures an
important architectural decision: what was decided, why, what alternatives
were considered, and what tradeoffs were accepted.

### History

ADRs were popularised by Michael Nygard in his 2011 blog post "Documenting
Architecture Decisions." They have since become standard practice in
engineering teams.

### Why ADRs?

Architecture decisions are often made in a meeting, Slack conversation,
or a developer's head. Without documentation:
- New engineers don't know why the system is the way it is
- The same debate happens repeatedly as team members change
- Decisions can be unknowingly reversed

ADRs create a permanent record of:
- The context that made this decision necessary
- The alternatives that were seriously considered
- Why the chosen option was preferred
- The tradeoffs that were accepted

### AlphaLab's ADR Structure

```markdown
# ADR-NNN — Decision Name

| Status | Accepted / Deprecated / Superseded |
| Phase  | When this decision was made       |

## Context
## Decision
## Alternatives Considered
## Tradeoffs
## Consequences
## Future Impact
```

### Interview Questions

**Q: Why write ADRs? Can't you just read the code?**
A: Code tells you what a system does. It cannot tell you what was considered
and rejected, what tradeoffs were accepted, or what constraints existed at
the time of the decision. ADRs capture the reasoning behind the code —
which is far more valuable for understanding a system than the code itself.

**Q: When should a new ADR be written?**
A: When a decision: (1) is hard to reverse, (2) affects multiple components,
or (3) involves choosing between reasonable alternatives. A decision like
"use Python" doesn't need an ADR. A decision like "use DuckDB for analytics
instead of keeping everything in PostgreSQL" does.
