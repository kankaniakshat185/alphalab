# Phase 00 — Engineering Foundation
## Development Log

> **Phase:** 0 — Engineering Foundation
> **Date:** 2026-07-05
> **Status:** Complete

---

## Planning

### Context

AlphaLab is a new project with no existing codebase. Phase 0 exists
to establish the engineering foundation before any business logic is written.
This prevents the common failure mode of retrofitting engineering discipline
onto an undisciplined codebase.

### Goals

1. Repository structure that can serve all 12 phases without refactoring
2. Documentation framework that prevents context loss between sessions
3. Engineering workflow that enforces quality at every stage
4. Infrastructure that is ready before the code that depends on it
5. CI/CD that catches regressions from the first commit

### What Was NOT in Scope

- Business logic of any kind
- Database models or migrations
- API routes
- DSL implementation
- Engine implementation
- Any Phase 1+ code

This boundary was enforced strictly. Several tempting additions were
considered and rejected:

| Considered | Rejected because |
|---|---|
| `src/alphalab/config/settings.py` | Phase 1 scope — no env vars needed in Phase 0 |
| `src/alphalab/common/exceptions.py` | Phase 1 scope — no domain exceptions until we have a domain |
| DuckDB as a dev dependency | Phase 1 scope — no data layer in Phase 0 |

### Engineering Review

Before implementation began, a critical engineering review of the initial
implementation plan was conducted. The review identified 12 weaknesses:

**High severity (fixed):**
- No tests — Phase 0 had zero tests despite the DoD requiring them
- No documentation update triggers — without them, the four-file system degrades
- No AI guardrails — nothing prevented future scope bleed

**Medium severity (fixed):**
- `build.yml` had no meaning for a Python application → renamed `install.yml`
- File reference planned for empty `__init__.py` files → deferred to Phase 1
- Missing `.python-version` and `.pre-commit-config.yaml`

**Items removed as premature:**
- `docs/api/`, `docs/deployment/` → created at Phase 6/10
- `internal/research/`, `experiments/`, `design_notes/`, `drafts/` → created when needed

**Items added:**
- `tests/test_package.py` — 11 smoke tests
- `.python-version` — Python 3.12 pinned
- `.pre-commit-config.yaml` — ruff + file hygiene hooks
- `.editorconfig` — consistent formatting
- `.github/CODEOWNERS` — automatic review assignment
- Documentation update matrix in `CONTRIBUTING.md`
- Phase Guard in `CONTRIBUTING.md`

---

## Implementation

### Implementation Order

Files were created in this order:

1. `.gitignore` — first, to prevent any accidental tracking
2. `.python-version` — pins interpreter before anything else
3. `.editorconfig` — formatting before any files are formatted
4. `LICENSE` — legal before anything is committed
5. `pyproject.toml` — package configuration before package files
6. `.pre-commit-config.yaml` — hooks before any commits
7. Source packages (`src/alphalab/` + 8 sub-packages) — structure before tests
8. Tests (`tests/` directory) — test infrastructure before CI
9. Infrastructure (`infra/docker-compose.yml`, `.env.example`)
10. GitHub workflows and templates
11. Public documentation (`docs/`)
12. ADRs
13. Root docs (`README.md`, `CONTRIBUTING.md`, `TASKS.md`)
14. Private documentation (`internal/`)

This order follows the principle: infrastructure before the things that depend on it.

---

## Files Created

### Root Files

| File | Why it was created |
|---|---|
| `.gitignore` | Prevent `internal/` and `.env` from ever reaching GitHub |
| `.python-version` | Pin Python 3.12 for pyenv/mise — prevents "works on my machine" |
| `.editorconfig` | Consistent formatting across editors without relying on personal settings |
| `.pre-commit-config.yaml` | Catch issues before they reach CI — cheaper than CI failures |
| `pyproject.toml` | Single source of truth for package config, tool config, and dependencies |
| `LICENSE` | MIT — required for an open-source portfolio project |

### Source Packages

Eight `__init__.py` files created, each containing only a module docstring.
The docstrings describe: the package's future responsibility, which phase
introduces real logic, and what the planned contents will be.

No logic was added. No imports beyond what Python requires. This is correct.

### Tests

`tests/test_package.py` contains 11 tests in three categories:
1. Import smoke tests (9 tests) — verify every package is importable
2. Structure completeness test (1 test) — verify all expected packages exist
3. `src/` layout test (1 test) — verify the package resolves from `src/`

All 11 tests pass.

### Infrastructure

`infra/docker-compose.yml` — Three services:
- PostgreSQL 16-alpine: always starts
- Redis 7-alpine: always starts
- pgAdmin 4: optional (`--profile tools`)

The pgAdmin profile decision was important: running pgAdmin by default
adds a third service, two volumes, and a health dependency on every
`docker compose up`. Making it optional keeps the default command lightweight.

### Public Documentation

Five core documents created:
- `00_MASTER_PLAN.md` — the constitution; explains the research thesis
- `01_ARCHITECTURE.md` — system architecture including planned schema and data flow
- `02_CURRENT_STATE.md` — Phase 0 completion status
- `03_NEXT_STAGE.md` — Phase 1 plan with acceptance criteria
- Three ADRs covering repository structure, documentation policy, project architecture

The architecture documents describe the full planned system, not just what exists
in Phase 0. This is correct: the architecture should be understood before it is built.

### CI/CD

Three GitHub Actions workflows:
- `lint.yml`: ruff check + mypy — catches code quality issues
- `test.yml`: pytest — catches regressions
- `install.yml`: clean pip install — catches pyproject.toml errors

The `install.yml` workflow is the most novel. Its purpose: verify that `pip install -e .`
succeeds on a clean environment with no cached state. This catches errors in
`pyproject.toml` that `lint.yml` and `test.yml` cannot, because they install
before running and would fail at the install step, not as a distinct CI check.

---

## Decisions Made

### 1. Python 3.12 (not 3.11)

3.12 is the latest stable release with better performance and improved error messages.
No Phase 0 code uses 3.12-specific features, but establishing 3.12 now prevents
a future upgrade migration.

### 2. Hatchling (not setuptools)

Hatchling is the modern build backend recommended by the Python Packaging Authority.
It is simpler to configure than setuptools for the `src/` layout and produces
cleaner error messages.

### 3. Ruff (not flake8 + isort + pyupgrade)

Ruff replaces three separate tools with a single binary that is 10–100× faster.
It is now the industry standard for Python linting. Using three separate tools
would add complexity with no benefit.

### 4. pgAdmin behind `--profile tools`

Discussed in the engineering review. The correct default is the smallest viable
`docker compose up` command. pgAdmin is a convenience tool; it should not be
part of the default startup.

---

## Problems Encountered

### Problem 1: Command permissions

Several shell commands required user approval before execution. This is
correct behaviour — the engineer should review and approve commands.
The implementation adapted by using `write_to_file` for all file creation
rather than shell scripts, which requires no command approval.

### Problem 2: PDF text extraction

The source documents (`.pdf` files) required PyMuPDF for text extraction.
PyMuPDF was already installed on the system, so this was resolved quickly.

---

## Lessons Learned

1. **Engineering reviews before implementation are valuable.** The review
   identified 12 real weaknesses in the initial plan. Several of them
   (no tests, no AI guardrails) would have caused problems in Phase 1.

2. **`internal/` as a gitignored notebook is the right pattern.** Having
   a local-only directory for learning notes and development diaries resolves
   the tension between "documentation should be thorough" and "private notes
   shouldn't be public."

3. **The Phase Guard belongs in `CONTRIBUTING.md`, not just in the engineering
   diary.** Making it a permanent written rule creates accountability.

---

## Final Outcome

Phase 0 is complete. The repository is:
- Structurally sound
- Fully documented
- CI/CD-ready
- Infrastructure-ready (Docker Compose)
- Testable (`pytest tests/ -v` passes)
- Pre-commit-enforced

The engineering foundation is clean. Phase 1 can begin from a position of
full confidence in the engineering infrastructure.

---

## Handoff to Phase 1

The Phase 1 engineer (or AI agent) should:

1. Read `docs/03_NEXT_STAGE.md` — the complete Phase 1 plan
2. Create a `feature/data-foundation` branch from `dev`
3. Follow the implementation order in `03_NEXT_STAGE.md`
4. Do not add any Phase 2+ code — the Phase Guard applies from the first commit

The first task in Phase 1 is `src/alphalab/config/settings.py` — the Settings class
is needed by every other Phase 1 component.
