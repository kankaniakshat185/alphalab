# Interview Defense — README

> **Purpose:** This directory contains interview defense documents — one per
> major AlphaLab subsystem. Each document prepares you to defend the
> architecture of that subsystem in a technical interview.

---

## Convention

One document per subsystem. Each document answers:

- Why this technology / design?
- Why not the alternatives?
- What tradeoffs were accepted?
- What is the scaling path?
- What are the most common interview questions?
- What are the ideal answers?

---

## Planned Documents (added as subsystems are built)

| Document | Phase | Subsystem |
|---|---|---|
| `Provider_Pattern.md` | 1 | Why abstract the data source? |
| `Universe_Abstraction.md` | 1 | Point-in-time vs static lists |
| `DuckDB.md` | 1 | DuckDB vs PostgreSQL vs Pandas |
| `DSL_Design.md` | 2 | Why a DSL instead of sandboxed Python? |
| `Walk_Forward_Validation.md` | 3 | Why not random train/test split? |
| `Celery.md` | 4 | Why Celery? Single queue justification |
| `Robustness_Engine.md` | 5 | The research thesis in engineering terms |
| `FastAPI.md` | 6 | Dependency injection, async, OpenAPI |
| `Dependency_Injection.md` | 6 | DI pattern in FastAPI |

---

## How to Use These Documents

Read the relevant document **before** any technical interview or review
where the corresponding subsystem will be discussed.

For each concept, be able to:
1. Explain it from first principles (as if to a non-expert)
2. Explain the tradeoff between this approach and the alternatives
3. Describe how AlphaLab uses it specifically
4. Describe what the scaling path would look like if the project grew

Phase 0 has no subsystems yet. This directory will be populated starting
from Phase 1.
