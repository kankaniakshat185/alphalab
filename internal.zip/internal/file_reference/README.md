# File Reference — README

> **Purpose:** This directory contains reference documents for every source
> file in `src/alphalab/` that contains meaningful behaviour.

---

## Convention

This directory mirrors the structure of `src/alphalab/`:

```
internal/file_reference/
  api/
    routes/
      factors.md        ← documents src/alphalab/api/routes/factors.py
  data/
    providers/
      yahoo.md          ← documents src/alphalab/data/providers/yahoo.py
  ...
```

---

## When to Create a Reference Document

**Create a reference document when a file:**
- Contains real logic (not just imports and docstrings)
- Has non-obvious responsibilities
- Has dependencies that aren't immediately clear from reading it

**Do NOT create a reference document for:**
- Empty `__init__.py` files — the package docstring is sufficient
- Simple data classes with no behaviour
- Files that are self-explanatory from their type annotations

---

## Reference Document Template

Each reference document answers:

```markdown
# <filename>

## Purpose
Why does this file exist?

## Responsibilities
What does it do? What does it NOT do?

## Why This File Exists
Why isn't this logic in a different file?

## Inputs
What does it receive?

## Outputs
What does it produce?

## Control Flow
Walk through the key execution path.

## Dependencies
What does it import? Why?

## Who Imports This File
What other files depend on this one?

## Error Handling
What can go wrong? How is it handled?

## Extension Points
How would you extend this if requirements changed?

## Common Modifications
What is most likely to change in this file?

## Interview Questions
What would an interviewer ask about this file?

## Potential Pitfalls
What mistakes are easy to make with this file?
```

---

## Phase 0 Status

No source files contain meaningful behaviour yet. Reference documents will
be created starting in Phase 1 as files gain real logic.

The first reference documents will be written for:
- `data/providers/base.py` (the abstract interface)
- `data/providers/yahoo.py` (the concrete implementation)
- `data/validation/checks.py` (validation logic)
